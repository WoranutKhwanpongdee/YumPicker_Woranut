import React from 'react';
import { createStackNavigator } from '@react-navigation/stack';
import HomeScreen from '../screens/HomeScreen';
import IngredientInputScreen from '../screens/IngredientInputScreen';
import ResultScreen from '../screens/ResultScreen';
import DetailScreen from '../screens/DetailScreen';
import RandomMenuScreen from '../screens/RandomMenuScreen';

const Stack = createStackNavigator();

export default function StackNavigator() {
  return (
    <Stack.Navigator initialRouteName="Home">
      <Stack.Screen name="Home" component={HomeScreen} />
      <Stack.Screen name="Input" component={IngredientInputScreen} />
      <Stack.Screen name="Results" component={ResultScreen} />
      <Stack.Screen name="Details" component={DetailScreen} />
      <Stack.Screen name="Random" component={RandomMenuScreen} />
    </Stack.Navigator>
  );
}
