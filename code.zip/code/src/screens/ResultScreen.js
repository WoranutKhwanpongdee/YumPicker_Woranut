import React from 'react';
import { View, Text, FlatList, TouchableOpacity, StyleSheet, Image } from 'react-native';
import recipes from '../data/recipes';

export default function ResultScreen({ route, navigation }) {
  const { ingredients } = route.params;

  const matched = recipes.filter(recipe =>
    recipe.ingredients.every(ing => ingredients.includes(ing))
  );

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Recipes You Can Make:</Text>
      
      {matched.length === 0 ? (
        <View style={styles.emptyContainer}>
          <Text style={styles.emptyText}>No recipes found with these ingredients.</Text>
          <Text style={styles.emptySubtext}>Try adding more ingredients or try different ones.</Text>
        </View>
      ) : (
        <FlatList
          data={matched}
          keyExtractor={item => item.id.toString()}
          contentContainerStyle={styles.listContainer}
          renderItem={({ item }) => (
            <TouchableOpacity 
              style={styles.recipeCard}
              onPress={() => navigation.navigate('Details', { recipe: item })}
            >
              <View style={styles.cardContent}>
                <View style={styles.imageContainer}>
                  {item.imageUrl ? (
                    <Image source={{ uri: item.imageUrl }} style={styles.image} />
                  ) : (
                    <View style={styles.placeholderImage}>
                      <Text style={styles.placeholderText}>🍲</Text>
                    </View>
                  )}
                </View>
                <View style={styles.textContainer}>
                  <Text style={styles.recipeName}>{item.name}</Text>
                  <Text style={styles.ingredientCount}>
                    {item.ingredients.length} ingredients
                  </Text>
                </View>
              </View>
            </TouchableOpacity>
          )}
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: '#FFF8E1',
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    marginBottom: 20,
    color: '#D84315',
    textAlign: 'center',
  },
  listContainer: {
    paddingBottom: 20,
  },
  recipeCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
    overflow: 'hidden',
  },
  cardContent: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  imageContainer: {
    width: 80,
    height: 80,
    borderRadius: 8,
    overflow: 'hidden',
    margin: 12,
    backgroundColor: '#FFCCBC',
  },
  image: {
    width: '100%',
    height: '100%',
    resizeMode: 'cover',
  },
  placeholderImage: {
    width: '100%',
    height: '100%',
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#FFCCBC',
  },
  placeholderText: {
    fontSize: 30,
  },
  textContainer: {
    flex: 1,
    padding: 12,
  },
  recipeName: {
    fontSize: 18,
    fontWeight: '600',
    color: '#4E342E',
    marginBottom: 4,
  },
  ingredientCount: {
    fontSize: 14,
    color: '#8D6E63',
  },
  emptyContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  emptyText: {
    fontSize: 18,
    fontWeight: '500',
    color: '#5D4037',
    textAlign: 'center',
    marginBottom: 8,
  },
  emptySubtext: {
    fontSize: 16,
    color: '#8D6E63',
    textAlign: 'center',
  },
});