import React from 'react';
import { View, Text, StyleSheet, ScrollView, Image } from 'react-native';

export default function DetailScreen({ route }) {
  const { recipe } = route.params;

  return (
    <ScrollView style={styles.container}>
      <View style={styles.imageContainer}>
        {recipe.imageUrl ? (
          <Image source={{ uri: recipe.imageUrl }} style={styles.image} />
        ) : (
          <View style={styles.placeholderImage}>
            <Text style={styles.placeholderText}>🍽️</Text>
          </View>
        )}
      </View>

      <View style={styles.contentContainer}>
        <Text style={styles.name}>{recipe.name}</Text>
        
        <View style={styles.infoBar}>
          <View style={styles.infoItem}>
            <Text style={styles.infoIcon}>⏱️</Text>
            <Text style={styles.infoText}>{recipe.cookTime || '30 mins'}</Text>
          </View>
          
          <View style={styles.infoItem}>
            <Text style={styles.infoIcon}>🔥</Text>
            <Text style={styles.infoText}>{recipe.difficulty || 'Easy'}</Text>
          </View>
          
          <View style={styles.infoItem}>
            <Text style={styles.infoIcon}>👥</Text>
            <Text style={styles.infoText}>{recipe.servings || '4 servings'}</Text>
          </View>
        </View>

        <View style={styles.section}>
          <Text style={styles.heading}>Ingredients</Text>
          <View style={styles.ingredientsList}>
            {recipe.ingredients.map((ingredient, index) => (
              <View key={index} style={styles.ingredientItem}>
                <Text style={styles.bulletPoint}>•</Text>
                <Text style={styles.ingredientText}>{ingredient}</Text>
              </View>
            ))}
          </View>
        </View>

        <View style={styles.section}>
          <Text style={styles.heading}>Instructions</Text>
          {typeof recipe.steps === 'string' ? (
            <Text style={styles.stepsText}>{recipe.steps}</Text>
          ) : (
            Array.isArray(recipe.steps) && recipe.steps.map((step, index) => (
              <View key={index} style={styles.stepItem}>
                <Text style={styles.stepNumber}>{index + 1}.</Text>
                <Text style={styles.stepText}>{step}</Text>
              </View>
            ))
          )}
        </View>

        {recipe.notes && (
          <View style={styles.section}>
            <Text style={styles.heading}>Notes</Text>
            <Text style={styles.notesText}>{recipe.notes}</Text>
          </View>
        )}
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFF8E1',
  },
  imageContainer: {
    width: '100%',
    height: 250,
    backgroundColor: '#FFCCBC',
  },
  image: {
    width: '100%',
    height: '100%',
    resizeMode: 'cover',
  },
  placeholderImage: {
    width: '100%',
    height: '100%',
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#FFCCBC',
  },
  placeholderText: {
    fontSize: 80,
  },
  contentContainer: {
    padding: 20,
  },
  name: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#D84315',
    marginBottom: 16,
  },
  infoBar: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    paddingVertical: 16,
    marginBottom: 20,
    borderTopWidth: 1,
    borderBottomWidth: 1,
    borderColor: '#FFCCBC',
  },
  infoItem: {
    alignItems: 'center',
  },
  infoIcon: {
    fontSize: 24,
    marginBottom: 4,
  },
  infoText: {
    fontSize: 14,
    color: '#5D4037',
  },
  section: {
    marginBottom: 24,
  },
  heading: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#5D4037',
    marginBottom: 12,
    paddingBottom: 8,
    borderBottomWidth: 1,
    borderBottomColor: '#FFCCBC',
  },
  ingredientsList: {
    marginLeft: 8,
  },
  ingredientItem: {
    flexDirection: 'row',
    marginBottom: 8,
    alignItems: 'center',
  },
  bulletPoint: {
    fontSize: 18,
    color: '#FF8A65',
    marginRight: 8,
  },
  ingredientText: {
    fontSize: 16,
    color: '#5D4037',
    flex: 1,
  },
  stepItem: {
    flexDirection: 'row',
    marginBottom: 16,
  },
  stepNumber: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#FF8A65',
    marginRight: 8,
    minWidth: 24,
  },
  stepText: {
    fontSize: 16,
    color: '#5D4037',
    flex: 1,
    lineHeight: 22,
  },
  stepsText: {
    fontSize: 16,
    color: '#5D4037',
    lineHeight: 22,
  },
  notesText: {
    fontSize: 16,
    color: '#8D6E63',
    fontStyle: 'italic',
    lineHeight: 22,
  },
});