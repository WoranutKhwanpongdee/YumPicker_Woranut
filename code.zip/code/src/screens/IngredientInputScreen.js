import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, KeyboardAvoidingView, Platform, ScrollView } from 'react-native';

export default function IngredientInputScreen({ navigation }) {
  const [input, setInput] = useState('');
  
  const handleSearch = () => {
    if (input.trim()) {
      navigation.navigate('Results', { ingredients: input.split(',').map(item => item.trim()) });
    }
  };
  
  return (
    <KeyboardAvoidingView 
      behavior={Platform.OS === "ios" ? "padding" : "height"}
      style={styles.container}
    >
      <ScrollView contentContainerStyle={styles.scrollContainer}>
        <View style={styles.contentContainer}>
          <Text style={styles.title}>What's in your kitchen?</Text>
          
          <View style={styles.inputContainer}>
            <Text style={styles.label}>Enter ingredients (comma separated):</Text>
            <TextInput
              style={styles.input}
              placeholder="e.g. egg, rice, onion"
              value={input}
              onChangeText={setInput}
              placeholderTextColor="#A1887F"
              multiline={true}
              numberOfLines={3}
              autoCapitalize="none"
            />
          </View>
          
          <View style={styles.suggestionContainer}>
            <Text style={styles.suggestionTitle}>Popular ingredients:</Text>
            <View style={styles.tagContainer}>
              {['chicken', 'garlic', 'onion', 'tomato', 'cheese'].map((item) => (
                <TouchableOpacity 
                  key={item} 
                  style={styles.tag}
                  onPress={() => {
                    const currentItems = input ? input.split(',').map(i => i.trim()) : [];
                    if (!currentItems.includes(item)) {
                      setInput(input ? `${input}, ${item}` : item);
                    }
                  }}
                >
                  <Text style={styles.tagText}>{item}</Text>
                </TouchableOpacity>
              ))}
            </View>
          </View>
          
          <TouchableOpacity
            style={styles.button}
            onPress={handleSearch}
            disabled={!input.trim()}
          >
            <Text style={styles.buttonText}>Find Recipes</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFF8E1',
  },
  scrollContainer: {
    flexGrow: 1,
  },
  contentContainer: {
    flex: 1,
    padding: 24,
    justifyContent: 'center',
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#D84315',
    marginBottom: 30,
    textAlign: 'center',
  },
  inputContainer: {
    marginBottom: 24,
  },
  label: {
    fontSize: 16,
    fontWeight: '600',
    marginBottom: 8,
    color: '#5D4037',
  },
  input: {
    borderWidth: 1,
    borderColor: '#D7CCC8',
    backgroundColor: '#FFFFFF',
    padding: 16,
    borderRadius: 12,
    fontSize: 16,
    minHeight: 100,
    textAlignVertical: 'top',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 2,
  },
  suggestionContainer: {
    marginBottom: 30,
  },
  suggestionTitle: {
    fontSize: 14,
    color: '#5D4037',
    marginBottom: 10,
  },
  tagContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
  },
  tag: {
    backgroundColor: '#FFCC80',
    paddingVertical: 8,
    paddingHorizontal: 14,
    borderRadius: 20,
    marginRight: 8,
    marginBottom: 8,
  },
  tagText: {
    color: '#5D4037',
    fontSize: 14,
  },
  button: {
    backgroundColor: '#FF8A65',
    paddingVertical: 16,
    borderRadius: 12,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 3,
    elevation: 4,
  },
  buttonText: {
    color: 'white',
    fontSize: 18,
    fontWeight: '600',
  },
});