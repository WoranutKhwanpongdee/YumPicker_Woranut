import React, { useEffect, useState } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, Image, ActivityIndicator } from 'react-native';
import recipes from '../data/recipes';

export default function RandomMenuScreen({ navigation }) {
  const [randomRecipe, setRandomRecipe] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Simulate loading for a smoother experience
    setTimeout(() => {
      const random = recipes[Math.floor(Math.random() * recipes.length)];
      setRandomRecipe(random);
      setLoading(false);
    }, 1000);
  }, []);

  return (
    <View style={styles.container}>
      <Text style={styles.heading}>Today's Special Pick</Text>
      
      {loading ? (
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#FF8A65" />
          <Text style={styles.loadingText}>Finding something delicious...</Text>
        </View>
      ) : (
        <View style={styles.recipeContainer}>
          <View style={styles.imageContainer}>
            {randomRecipe.imageUrl ? (
              <Image source={{ uri: randomRecipe.imageUrl }} style={styles.image} />
            ) : (
              <View style={styles.placeholderImage}>
                <Text style={styles.placeholderText}>🍲</Text>
              </View>
            )}
          </View>
          
          <Text style={styles.recipeTitle}>{randomRecipe.name}</Text>
          
          <View style={styles.infoContainer}>
            <View style={styles.infoItem}>
              <Text style={styles.infoIcon}>⏱️</Text>
              <Text style={styles.infoText}>{randomRecipe.cookTime || '30 mins'}</Text>
            </View>
            
            <View style={styles.infoItem}>
              <Text style={styles.infoIcon}>🔥</Text>
              <Text style={styles.infoText}>{randomRecipe.difficulty || 'Easy'}</Text>
            </View>
            
            <View style={styles.infoItem}>
              <Text style={styles.infoIcon}>👥</Text>
              <Text style={styles.infoText}>{randomRecipe.servings || '4 servings'}</Text>
            </View>
          </View>
          
          <TouchableOpacity 
            style={styles.button}
            onPress={() => navigation.navigate('Details', { recipe: randomRecipe })}
          >
            <Text style={styles.buttonText}>See Full Recipe</Text>
          </TouchableOpacity>
          
          <TouchableOpacity 
            style={styles.secondaryButton}
            onPress={() => {
              setLoading(true);
              setTimeout(() => {
                const newRandom = recipes[Math.floor(Math.random() * recipes.length)];
                setRandomRecipe(newRandom);
                setLoading(false);
              }, 1000);
            }}
          >
            <Text style={styles.secondaryButtonText}>Try Another</Text>
          </TouchableOpacity>
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 24,
    backgroundColor: '#FFF8E1',
  },
  heading: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#D84315',
    textAlign: 'center',
    marginVertical: 20,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadingText: {
    marginTop: 16,
    fontSize: 16,
    color: '#5D4037',
    fontStyle: 'italic',
  },
  recipeContainer: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  imageContainer: {
    width: '100%',
    height: 220,
    borderRadius: 16,
    overflow: 'hidden',
    marginBottom: 20,
    backgroundColor: '#FFCCBC',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
    elevation: 5,
  },
  image: {
    width: '100%',
    height: '100%',
    resizeMode: 'cover',
  },
  placeholderImage: {
    width: '100%',
    height: '100%',
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#FFCCBC',
  },
  placeholderText: {
    fontSize: 60,
  },
  recipeTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#4E342E',
    marginBottom: 16,
    textAlign: 'center',
  },
  infoContainer: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    width: '100%',
    marginBottom: 30,
  },
  infoItem: {
    alignItems: 'center',
    paddingHorizontal: 10,
  },
  infoIcon: {
    fontSize: 24,
    marginBottom: 5,
  },
  infoText: {
    color: '#5D4037',
    fontSize: 14,
  },
  button: {
    backgroundColor: '#FF8A65',
    paddingVertical: 16,
    paddingHorizontal: 32,
    borderRadius: 12,
    width: '100%',
    alignItems: 'center',
    marginBottom: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 3,
    elevation: 4,
  },
  buttonText: {
    color: 'white',
    fontSize: 18,
    fontWeight: '600',
  },
  secondaryButton: {
    backgroundColor: 'transparent',
    paddingVertical: 12,
    paddingHorizontal: 24,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: '#FF8A65',
    width: '100%',
    alignItems: 'center',
  },
  secondaryButtonText: {
    color: '#FF8A65',
    fontSize: 16,
    fontWeight: '500',
  },
});