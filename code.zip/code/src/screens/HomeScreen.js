import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet, ImageBackground, StatusBar } from 'react-native';

export default function HomeScreen({ navigation }) {
  return (
    <View style={styles.container}>
      <StatusBar barStyle="dark-content" />
      
      <View style={styles.titleContainer}>
        <Text style={styles.emoji}>🍽</Text>
        <Text style={styles.title}>YumPicker</Text>
        <Text style={styles.subtitle}>Find your perfect meal</Text>
      </View>
      
      <View style={styles.buttonContainer}>
        <TouchableOpacity 
          style={[styles.button, styles.recipeButton]}
          onPress={() => navigation.navigate('Input')}
        >
          <Text style={styles.buttonText}>Find Recipes</Text>
        </TouchableOpacity>
        
        <TouchableOpacity 
          style={[styles.button, styles.randomButton]}
          onPress={() => navigation.navigate('Random')}
        >
          <Text style={styles.buttonText}>Random Menu</Text>
        </TouchableOpacity>
      </View>
      
      <View style={styles.footer}>
        <Text style={styles.footerText}>Discover delicious meals</Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'space-between',
    paddingVertical: 60,
    paddingHorizontal: 20,
    backgroundColor: '#FFF8E1',
  },
  titleContainer: {
    alignItems: 'center',
    marginTop: 40,
  },
  emoji: {
    fontSize: 60,
    marginBottom: 10,
  },
  title: {
    fontSize: 42,
    fontWeight: 'bold',
    color: '#D84315',
    textShadowColor: 'rgba(0, 0, 0, 0.1)',
    textShadowOffset: { width: 1, height: 1 },
    textShadowRadius: 2,
  },
  subtitle: {
    fontSize: 18,
    color: '#5D4037',
    marginTop: 10,
    fontWeight: '500',
  },
  buttonContainer: {
    width: '100%',
    paddingHorizontal: 20,
    marginVertical: 40,
  },
  button: {
    borderRadius: 12,
    marginVertical: 10,
    paddingVertical: 16,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 3,
    elevation: 4,
  },
  recipeButton: {
    backgroundColor: '#FF8A65',
  },
  randomButton: {
    backgroundColor: '#7986CB',
  },
  buttonText: {
    color: '#FFFFFF',
    fontSize: 18,
    fontWeight: '600',
    letterSpacing: 0.5,
  },
  footer: {
    alignItems: 'center',
    marginBottom: 20,
  },
  footerText: {
    color: '#78909C',
    fontSize: 14,
    fontStyle: 'italic',
  }
});