export default [
    {
      id: 1,
      name: 'Fried Egg with Rice',
      ingredients: ['egg', 'rice', 'oil'],
      steps: '1. Heat oil. 2. Fry the egg. 3. Serve with rice.',
    },
    {
      id: 2,
      name: 'Stir-fried Vegetables',
      ingredients: ['vegetables', 'garlic', 'oil', 'soy sauce'],
      steps: '1. Chop veggies. 2. Stir-fry garlic. 3. Add veggies and sauce.',
    },
  ];
  